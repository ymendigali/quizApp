//
//  QuizViewController.swift
//  quizApp
//
//  Created by Yersultan Mendigali on 27.01.2021.
//

import UIKit

protocol PassResultData: AnyObject {
    func passResult(count: Int)
}

class QuizViewController: UIViewController {

    @IBOutlet weak var questionNumberLabel: UILabel!
    @IBOutlet weak var questionField: UILabel!
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var prevButton: UIButton!
    
    var questions = ["Capital of Kazakhstan?","Capital of Russia?","Capital of Canada?","Capital of England?","Capital of Spain?","Capital of France?","Capital of Japan?","Capital of USA?","Capital of Argentina?","Capital of Turkey?"]
    var answers = ["Nursultan","Moscow","Toronto","London","Madrid","Paris","Tokio","Washington","BuenosAires","Ankara"]
    var fakeAnswers = ["Almaty","Shymkent","Krasnodar","Rome","Barcelona","Marbella","Osaka","Nagoyo","Hong-Kong","Amsterdam","Istanbul","Belek","Vancouer","Monreal","New-York","Chicago","Nicce","Mexico","Manchester","Marselle"]
    
    
    var counter = 1
    var result = 0
    
    weak var delegate: PassResultData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.SetUpQuestions()
        
    }
    
    @IBAction func button1Func(_ sender: Any) {
        result += 1
    }
    
    func SetUpQuestions(){
        questionNumberLabel.text = "\(counter)/10"
        questionField.text = questions[counter-1]
        button1.setTitle("\(answers[counter-1])", for: .normal)
        button2.setTitle("\(fakeAnswers[self.randomize()])", for: .normal)
        button3.setTitle("\(fakeAnswers[self.randomize()])", for: .normal)
        button4.setTitle("\(fakeAnswers[self.randomize()])", for: .normal)
    }
    
    @IBAction func prevFunc(_ sender: Any) {
        if counter != 1 {
            counter -= 1
        }
        self.SetUpQuestions()
    }
    
    func randomize() -> Int {
        return Int.random(in: 0..<10)
    }
    
    @IBAction func nextFunc(_ sender: Any) {
        if counter != 10 {
            counter += 1
        }
        if counter == 10 {
            self.SetUpQuestions()
            nextButton.setTitle("Finish attempt", for: .normal)
            self.delegate?.passResult(count: result)
            counter += 1
        }
        if counter == 11 {
            let vc = storyboard?.instantiateViewController(identifier: "ResultViewController") as! ResultViewController
            vc.res = result
            counter = 1
            result = 0
            navigationController?.pushViewController(vc, animated: true)
        }
        self.SetUpQuestions()
    }
    
}
