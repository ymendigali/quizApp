import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    var resArr = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = UIImage(named: "geog")
    }

    @IBAction func startFunc(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "QuizViewController") as! QuizViewController
        navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func historyFunc(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "HistoryViewController") as! HistoryViewController
        vc.resultArrHistory.append(resArr[resArr.count-1])
        navigationController?.pushViewController(vc, animated: true)
    }
        
    @IBOutlet weak var textField: UITextField!
    
}

